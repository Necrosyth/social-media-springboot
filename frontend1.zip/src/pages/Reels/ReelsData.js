export const reels = [
  
  {
    video:
      "https://res.cloudinary.com/dnbw04gbs/video/upload/v1683395722/instagram%20post/wryl287vsxw5uzp2j3hw.mp4",
  },
  {
    video:"https://res.cloudinary.com/dnbw04gbs/video/upload/v1683395722/instagram%20post/wryl287vsxw5uzp2j3hw.mp4"
  },
  {
    video:"https://res.cloudinary.com/dnbw04gbs/video/upload/v1683396395/instagram%20post/kjcdslqvcyf2zltjffhs.mp4"
  },
  
  {
    video:"https://res.cloudinary.com/dnbw04gbs/video/upload/v1683400385/instagram%20post/qrtcrabfo5yggkhmlzmr.mp4"
  },
  {
    video:"https://res.cloudinary.com/dnbw04gbs/video/upload/v1683400385/instagram%20post/qrtcrabfo5yggkhmlzmr.mp4"
  },
  {
    video:"https://res.cloudinary.com/dnbw04gbs/video/upload/v1683400385/instagram%20post/qrtcrabfo5yggkhmlzmr.mp4"
  },
  {
    video:"https://res.cloudinary.com/dnbw04gbs/video/upload/v1683400385/instagram%20post/qrtcrabfo5yggkhmlzmr.mp4"
  },
  {
    video:"https://res.cloudinary.com/dnbw04gbs/video/upload/v1683400385/instagram%20post/qrtcrabfo5yggkhmlzmr.mp4"
  },
  {
    video:"https://res.cloudinary.com/dnbw04gbs/video/upload/v1683400385/instagram%20post/qrtcrabfo5yggkhmlzmr.mp4"
  },
  {
    video:"https://res.cloudinary.com/dnbw04gbs/video/upload/v1683400385/instagram%20post/qrtcrabfo5yggkhmlzmr.mp4"
  },
  {
    video:"https://res.cloudinary.com/dnbw04gbs/video/upload/v1683400385/instagram%20post/qrtcrabfo5yggkhmlzmr.mp4"
  },
  
];
