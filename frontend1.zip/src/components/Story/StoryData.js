export const story = [
    {
      image:
        "https://thispersondoesnotexist.com/",
      username: "TestUser1",
      userId: 1,
    },
    {
      image:
        "https://picsum.photos/400/500",
      username: "Ramu",
      userId: 1,
    },
    {
      image:
        "https://picsum.photos/300/400",
      username: "George",
      userId: 1,
    },
    {
      image:
        "https://picsum.photos/100/200",
      username: "Paul",
      userId: 4,
    },
    {
      image:
        "https://picsum.photos/200/300",
      username: "John",
      userId: 5,
    },
  ];